namespace MovieStore.Models.DTO;

public class Actor
{
    public int ID { get; set; }
    
    public string Name { get; set; } = string.Empty;
}