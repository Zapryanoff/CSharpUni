﻿using MovieStore.Models.DTO;
using System.Drawing;

namespace MovieStore.DL.StaticDB
{
    internal static class InMemoryDb
    {
        internal static List<Color> Colors = new List<Color>
        {
            new Color
            {
                Id = "1",
                Name = "Red"
            },
            new Color
            {
                Id = "2",
                Name = "Blue"
            },
            new Color
            {
                Id = "3",
                Name = "Green"
            },
            new Color
            {
                Id = "4",
                Name = "Black"
            },
            new Color
            {
                Id = "5",
                Name = "White"
            },
            new Color
            {
                Id = "6",
                Name = "Yellow"
            }
        };

        internal static List<Car> Cars = new List<Car>
        {
            new Car
            {
                Id = "1",
                Model = "Toyota Camry",
                Year = 2020,
                Colors = new List<string> { "1", "2" } 
            },
            new Car
            {
                Id = "2",
                Model = "Ford Mustang",
                Year = 2021,
                Colors = new List<string> { "3", "4" }  
            },
            new Car
            {
                Id = "3",
                Model = "Chevrolet Camaro",
                Year = 2022,
                Colors = new List<string> { "5", "6" }  
            }
        };
    }
}
