﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using CarStore.DL.Interfaces;
using CarStore.Models.Configurations;
using CarStore.Models.DTO;

namespace CarStore.DL.Repositories.MongoRepositories
{
    public class ColorRepository : IColorRepository
    {
        private readonly IMongoCollection<Color> _colors;
        private readonly ILogger<ColorRepository> _logger;

        public ColorRepository(
            IOptionsMonitor<MongoDbConfiguration> mongoConfig,
            ILogger<ColorRepository> logger)
        {
            _logger = logger;
            var client = new MongoClient(
                mongoConfig.CurrentValue.ConnectionString);

            var database = client.GetDatabase(
                mongoConfig.CurrentValue.DatabaseName);

            _colors = database.GetCollection<Color>(
                $"{nameof(Color)}s");
        }

        public void AddColor(Color color)
        {
            color.Id = System.Guid.NewGuid().ToString();
            _colors.InsertOne(color);
        }

        public IEnumerable<Color> GetColorsByIds(IEnumerable<string> colorIds)
        {
            var result = _colors.Find(color => colorIds.Contains(color.Id)).ToList();
            return result;
        }

        public Color? GetById(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;

            return _colors.Find(c => c.Id == id)
                .FirstOrDefault();
        }
    }
}
