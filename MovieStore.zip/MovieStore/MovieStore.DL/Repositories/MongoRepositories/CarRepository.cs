﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using CarStore.DL.Interfaces;
using CarStore.Models.Configurations;
using CarStore.Models.DTO;
using MovieStore.Models.Configurations;

namespace CarStore.DL.Repositories.MongoRepositories
{
    public class CarRepository : ICarRepository
    {
        private readonly IMongoCollection<Car> _cars;
        private readonly ILogger<CarRepository> _logger;

        public CarRepository(
            IOptionsMonitor<MongoDbConfiguration> mongoConfig,
            ILogger<CarRepository> logger)
        {
            _logger = logger;
            var client = new MongoClient(
                mongoConfig.CurrentValue.ConnectionString);

            var database = client.GetDatabase(
                mongoConfig.CurrentValue.DatabaseName);

            _cars = database.GetCollection<Car>(
                $"{nameof(Car)}s");
        }

        public List<Car> GetAllCars()
        {
            return _cars.Find(car => true).ToList();
        }

        public void AddCar(Car car)
        {
            if (car == null)
            {
                _logger.LogError("Car is null");
                return;
            }

            try
            {
                car.Id = Guid.NewGuid().ToString();

                _cars.InsertOne(car);
            }
            catch (Exception e)
            {
                _logger.LogError(e,
                    $"Error adding car {e.Message}-{e.StackTrace}");
            }
        }

        public Car? GetCarById(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;

            return _cars.Find(c => c.Id == id)
                .FirstOrDefault();
        }
    }
}
