﻿using CarStore.DL.StaticDB;
using CarStore.Models.DTO;
using System.Drawing;

namespace CarStore.DL.Repositories
{
    internal class ColorStaticRepository
    {
        public List<Color> GetAllColors()
        {
            return InMemoryDb.Colors;  
        }

        public void AddColor(Color color)
        {
            if (color == null) return;

            color.Id = Guid.NewGuid().ToString();  /
            InMemoryDb.Colors.Add(color);  
        }
        public Color? GetColorById(string id)
        {
            return InMemoryDb.Colors
                .FirstOrDefault(c => c.Id == id);
        }
    }
}
