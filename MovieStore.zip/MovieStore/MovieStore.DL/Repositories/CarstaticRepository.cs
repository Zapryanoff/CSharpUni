﻿using CarStore.DL.Interfaces;
using CarStore.Models.DTO;

namespace CarStore.DL.Repositories
{
    public class CarStaticRepository : ICarRepository
    {
        public IEnumerable<Car> GetCarsByIds(IEnumerable<string> carIds)
        {
            var result = new List<Car>();

            foreach (var carId in carIds)
            {
                foreach (var car in StaticDB.InMemoryDb.Cars)
                {
                    if (car.Id == carId)
                    {
                        result.Add(car);
                    }
                }
            }

            return result;
        }

        public Car? GetById(string id)
        {
            return StaticDB.InMemoryDb.Cars
                .FirstOrDefault(x => x.Id == id);
        }
    }
}
