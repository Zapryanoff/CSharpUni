﻿using CarStore.Models.DTO;

namespace CarStore.DL.Interfaces
{
    public interface IColorRepository
    {
        void AddColor(Color color);
        IEnumerable<Color> GetColorsByIds(IEnumerable<string> colorIds);
        Color? GetById(string id);
    }
}