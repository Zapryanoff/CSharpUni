﻿using CarStore.Models.DTO;

namespace CarStore.DL.Interfaces
{
    public interface ICarRepository
    {
        List<Car> GetAllCars();
        void AddCar(Car car);
        Car? GetCarById(string id);

    }
}
