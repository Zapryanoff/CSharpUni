﻿using CarStore.DL.Interfaces;
using CarStore.DL.Repositories.MongoRepositories;
using Microsoft.Extensions.DependencyInjection;

namespace CarStore.DL
{
    public static class DependencyInjection
    {
        public static void RegisterRepositories(this IServiceCollection services)
        {
            services
                .AddSingleton<ICarRepository, CarRepository>()  
                .AddSingleton<IColorRepository, ColorRepository>(); // 
        }
    }
}
