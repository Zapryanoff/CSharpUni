﻿namespace CarStore.Models.DTO
{
    public class Color
    {
        public string Id { get; set; }

        public string Name { get; set; } 
            = string.Empty;
    }
}
