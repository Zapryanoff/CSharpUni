﻿namespace CarStore.Models.DTO
{
    public class Car
    {
        public string Id { get; set; }

        public string Title { get; set; } = string.Empty;

        public int Year { get; set; }

        public List<string> Colors { get; set; }
    }
}
