﻿using CarStore.Models.Views;

namespace CarStore.Models.Responses
{
    public class GetFullCarDetailsResponse
    {
        IEnumerable<CarView> Cars { get; set; } = [];
    }
}
