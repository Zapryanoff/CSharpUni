﻿using CarStore.Models.DTO;

namespace CarStore.Models.Responses
{
    public class GetDetailedMovieResponse
    {
        public Car Car { get; set; }

        public List<Color> Colors { get; set; }
    }
}
