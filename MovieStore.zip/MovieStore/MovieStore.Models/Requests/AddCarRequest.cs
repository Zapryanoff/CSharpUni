﻿namespace CarStore.Models.Requests
{
    public class AddCarRequest
    {
        public string Title { get; set; }

        public int Year { get; set; }

        public List<string> Colors { get; set; }
    }
}
