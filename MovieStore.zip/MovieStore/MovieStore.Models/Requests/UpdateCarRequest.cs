﻿namespace CarStore.Models.Requests
{
    public class UpdateCarRequest
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public int Year { get; set; }
    }
}
