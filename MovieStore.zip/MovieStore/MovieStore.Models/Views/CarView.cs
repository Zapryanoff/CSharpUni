﻿using CarStore.Models.DTO;

namespace CarStore.Models.Views
{
    public class CarView
    {
        public string CarId { get; set; }

        public string CarTitle { get; set; } = string.Empty;

        public int CarYear { get; set; }

        public IEnumerable<Color> Colors { get; set; } = [];
    }
}
