using MapsterMapper;
using Microsoft.AspNetCore.Mvc;
using CarStore.BL.Interfaces;
using CarStore.Models.DTO;
using CarStore.Models.Requests;
using Microsoft.AspNetCore.Cors.Infrastructure;

namespace CarStore.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CarsController : ControllerBase
    {
        private readonly ICarService _carService;
        private readonly IMapper _mapper;
        private readonly ILogger<CarsController> _logger;

        public CarsController(
            ICarService carService,
            IMapper mapper,
            ILogger<CarsController> logger)
        {
            _carService = carService;
            _mapper = mapper;
            _logger = logger;
        }

        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [HttpGet("GetAll")]
        public IActionResult Get()
        {
            var result = _carService.GetAllCars();

            if (result == null || result.Count == 0)
            {
                return NotFound("No cars found");
            }

            return Ok(result);
        }

        [HttpGet("GetById")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult GetById(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return BadRequest("Id can't be null or empty");
            }

            var result = _carService.GetById(id);

            if (result == null)
            {
                return NotFound($"Car with ID:{id} not found");
            }

            return Ok(result);
        }

        [HttpPost("Add")]
        public IActionResult Add(AddCarRequest car)
        {
            try
            {
                var carDto = _mapper.Map<Car>(car);

                if (carDto == null)
                {
                    return BadRequest("Can't convert car to car DTO");
                }

                _carService.AddCar(carDto);

                return Ok();
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"Error adding car");
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("Delete")]
        public IActionResult Delete(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Id must be greater than 0");
            }

            //_carService.Delete(id);

            return Ok();
        }
    }
}
