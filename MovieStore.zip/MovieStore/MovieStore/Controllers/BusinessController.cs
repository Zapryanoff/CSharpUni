using Microsoft.AspNetCore.Mvc;
using CarStore.BL.Interfaces;
using CarStore.Models.DTO;
using System.Drawing;

namespace CarStore.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CarBusinessController : ControllerBase
    {
        private readonly ICarBlService _carService;
        private readonly IColorService _colorService;

        public CarBusinessController(ICarBlService carService, IColorService colorService)
        {
            _carService = carService;
            _colorService = colorService;
        }

        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [HttpGet("GetAllCarsWithDetails")]
        public IActionResult GetAllCarsWithDetails()
        {
            var result = _carService.GetDetailedCars();

            if (result == null || result.Count == 0)
            {
                return NotFound("No cars found");
            }

            return Ok(result);
        }

        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [HttpPost("AddColor")]
        public IActionResult AddColor([FromBody] Color color)
        {
            _colorService.Add(color);

            return Ok();
        }
    }
}
