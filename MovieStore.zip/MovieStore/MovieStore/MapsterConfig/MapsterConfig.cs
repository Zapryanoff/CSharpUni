﻿using Mapster;
using CarStore.Models.DTO;
using CarStore.Models.Requests;

namespace CarStore.MapsterConfig
{
    public class MapsterConfiguration
    {
        public static void Configure()
        {
            TypeAdapterConfig<Car, AddCarRequest>
                .NewConfig()
                .TwoWays();
        }
    }
}
