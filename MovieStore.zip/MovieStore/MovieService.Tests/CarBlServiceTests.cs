using CarStore.BL.Interfaces;
using CarStore.BL.Services;
using CarStore.DL.Interfaces;
using CarStore.Models.DTO;
using Moq;

namespace CarStore.Tests
{
    public class CarBlServiceTests
    {
        private Mock<ICarService> _carServiceMock;
        private Mock<IColorRepository> _colorRepositoryMock;

        public CarBlServiceTests()
        {
            _carServiceMock = new Mock<ICarService>();
            _colorRepositoryMock = new Mock<IColorRepository>();
        }

        private List<Car> _cars = new List<Car>
        {
            new Car()
            {
                Id = Guid.NewGuid().ToString(),
                Make = "Car 1",
                Model = "Model 1",
                Year = 2021,
                Colors = new List<string> { "Color 1", "Color 2" }
            },
            new Car()
            {
                Id = Guid.NewGuid().ToString(),
                Make = "Car 2",
                Model = "Model 2",
                Year = 2022,
                Colors = new List<string> { "Color 3", "Color 4" }
            }
        };

        private List<Color> _colors = new List<Color>
        {
            new Color()
            {
                Id = "157af604-7a4b-4538-b6a9-fed41a41cf3a",
                Name = "Color 1"
            },
            new Color()
            {
                Id = "baac2b19-bbd2-468d-bd3b-5bd18aba98d7",
                Name = "Color 2"
            },
            new Color()
            {
                Id = "5c93ba13-e803-49c1-b465-d471607e97b3",
                Name = "Color 3"
            },
            new Color()
            {
                Id = "9badefdc-0714-4581-80ae-161cd0a5abbe",
                Name = "Color 4"
            }
        };

        [Fact]
        public void GetDetailedCars_Ok()
        {
            // setup
            var expectedCount = 2;

            _carServiceMock
                .Setup(x => x.GetAllCars())
                .Returns(_cars);
            _colorRepositoryMock.Setup(x =>
                    x.GetById(It.IsAny<string>()))
                .Returns((string id) =>
                    _colors.FirstOrDefault(x => x.Id == id));

            // inject
            var carBlService = new CarBlService(
                _carServiceMock.Object,
                _colorRepositoryMock.Object);

            // Act
            var result =
                carBlService.GetDetailedCars();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedCount, result.Count);
        }
    }
}
