﻿using CarStore.Models.DTO;

namespace CarStore.BL.Interfaces
{
    public interface ICarService
    {
        List<Car> GetAllCars();

        void AddCar(Car car);

        Car? GetById(string id);
    }
}
