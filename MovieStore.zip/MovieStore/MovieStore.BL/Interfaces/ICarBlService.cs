﻿using CarStore.Models.Views;

namespace CarStore.BL.Interfaces
{
    public interface ICarBlService
    {
        List<CarView> GetDetailedCars();
    }
}
