﻿using CarStore.Models.DTO;
using System.Drawing;

namespace CarStore.BL.Interfaces
{
    public interface IColorService
    {
        void Add(Color color);
    }
}
