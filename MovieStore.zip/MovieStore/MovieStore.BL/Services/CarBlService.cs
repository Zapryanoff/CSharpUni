﻿using CarStore.BL.Interfaces;
using CarStore.DL.Interfaces;
using CarStore.Models.DTO;
using CarStore.Models.Views;

namespace CarStore.BL.Services
{
    internal class CarBlService : ICarBlService
    {
        private readonly ICarService _carService;
        private readonly IColorRepository _colorRepository;

        public CarBlService(
            ICarService carService,
            IColorRepository colorRepository)
        {
            _carService = carService;
            _colorRepository = colorRepository;
        }

        public List<CarView> GetDetailedCars()
        {
            var result = new List<CarView>();

            var cars = _carService.GetAllCars();

            foreach (var car in cars)
            {
                var carView = new CarView
                {
                    CarId = car.Id,
                    CarTitle = car.Title,
                    CarYear = car.Year,
                    Colors = _colorRepository.GetColorsByIds(car.Colors)
                };

                result.Add(carView);
            }

            return result;
        }
    }
}
