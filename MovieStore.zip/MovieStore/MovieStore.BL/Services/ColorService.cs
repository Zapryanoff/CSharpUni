﻿using CarStore.BL.Interfaces;
using CarStore.DL.Interfaces;
using CarStore.Models.DTO;
using System.Drawing;

namespace CarStore.BL.Services
{
    internal class ColorService : IColorService
    {
        private readonly IColorRepository _colorRepository;

        public ColorService(IColorRepository colorRepository)
        {
            _colorRepository = colorRepository;
        }

        public void Add(Color color)
        {
            _colorRepository.AddColor(color);
        }
    }
}
