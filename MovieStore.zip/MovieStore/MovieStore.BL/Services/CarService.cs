﻿using CarStore.BL.Interfaces;
using CarStore.DL.Interfaces;
using CarStore.Models.DTO;

namespace CarStore.BL.Services
{
    public class CarService : ICarService
    {
        private readonly ICarRepository _carRepository;
        private readonly IColorRepository _colorRepository;

        public CarService(ICarRepository carRepository, IColorRepository colorRepository)
        {
            _carRepository = carRepository;
            _colorRepository = colorRepository;
        }

        public List<Car> GetAllCars()
        {
            return _carRepository.GetAllCars();
        }

        public void AddCar(Car? car)
        {
            if (car is null) return;

            foreach (var carColor in car.Colors)
            {
                var color = _colorRepository.GetById(carColor);

                if (color is null)
                {
                    throw new Exception(
                        $"Color with id {carColor} does not exist");
                }
            }

            _carRepository.AddCar(car);
        }

        public Car? GetById(string id)
        {
            return _carRepository.GetCarById(id);
        }
    }
}
