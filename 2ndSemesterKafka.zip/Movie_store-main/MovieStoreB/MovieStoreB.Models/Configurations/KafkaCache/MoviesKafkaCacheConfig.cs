﻿namespace MovieStoreB.Models.Configurations.KafkaCache
{
    public class MoviesKafkaCacheConfig : BaseKafkaCacheConfig
    {
       
    }
}
