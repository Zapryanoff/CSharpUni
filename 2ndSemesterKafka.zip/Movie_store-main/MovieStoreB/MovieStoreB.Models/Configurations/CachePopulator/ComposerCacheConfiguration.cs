﻿namespace MovieStoreB.Models.Configurations.CachePopulator
{
    public class ComposerCacheConfiguration : CacheConfiguration
    {
    }
}
