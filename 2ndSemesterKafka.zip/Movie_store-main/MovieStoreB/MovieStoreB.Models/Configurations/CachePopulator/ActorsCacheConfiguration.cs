﻿namespace MovieStoreB.Models.Configurations.CachePopulator
{

    public class ActorsCacheConfiguration : CacheConfiguration
    {
    }
       
}
