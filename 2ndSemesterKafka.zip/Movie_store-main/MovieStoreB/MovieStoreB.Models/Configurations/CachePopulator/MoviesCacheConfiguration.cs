﻿namespace MovieStoreB.Models.Configurations.CachePopulator
{
    public class MoviesCacheConfiguration : CacheConfiguration
    {
    }
}
