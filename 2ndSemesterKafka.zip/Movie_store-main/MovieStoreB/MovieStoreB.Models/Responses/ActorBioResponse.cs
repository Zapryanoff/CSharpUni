namespace MovieStoreB.Models.Responses
{
    public class ActorBioResponse
    {
        public string? Summary { get; set; }
    }
}
