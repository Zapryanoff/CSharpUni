﻿namespace MovieStoreB.DL.Cache
{
    public class MongoCache<T>
    {
    }
}
